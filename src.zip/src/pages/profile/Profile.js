import React, { useEffect, useId } from 'react'
import { useDispatch } from 'react-redux'
import { useSelectorUserState } from '../../redux/slices/AuthSlice';
import { getuserdata, useSelectorUserAction } from '../../redux/slices/UserActionSlice';

const Profile = () => {
    const dispatch = useDispatch();
    const { userid } = useSelectorUserState();
    dispatch(getuserdata(userid));
    return (
        <div>
            <div className='fm:hidden flex'>
                <div className='w-1/5 flex justify-center items-center'>
                    <div className='w-full flex justify-center items-center'>
                        <img className='rounded-full' width={'150px'} src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSy2Vzf90CMXNaJzJ6kKGm-nGNhmYIhkDGEFV6SzvfcuEY5MlvGLFfPHFlOwxVTWuqFZm0&usqp=CAU' alt='profile'></img>
                    </div>
                </div>
                <div className='flex-grow'>

                </div>
                <div></div>
            </div>
        </div>
    )
}

export default Profile
