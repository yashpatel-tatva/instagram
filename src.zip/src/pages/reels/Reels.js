import React from 'react'

const Reels = () => {
    return (
        <div>
            Reels
        </div>
    )
}

export default Reels
