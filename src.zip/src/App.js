import { useDispatch } from 'react-redux';
import './App.css';
import SideBottomBar from './layouts/SideBottomBar';
import { authAction, useSelectorUserState } from './redux/slices/AuthSlice';
import { AuthRoutes, NormalRoutes } from './routes/CustomRoutes';
import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

function App() {
  const { isLoggedIn } = useSelectorUserState();
  const dispatch = useDispatch();
  const location = useLocation();

  // useEffect(() => {
  //   if (!isLoggedIn) return;
  //   dispatch(authAction.setuser());
  // }, [dispatch, isLoggedIn]);

  useEffect(() => {
    dispatch(authAction.resetErrors());
  }, [location.pathname]);


  return (
    <>
      {!isLoggedIn ? (
        <AuthRoutes />
      ) : (
        <SideBottomBar>
          <NormalRoutes />
        </SideBottomBar>
      )}
    </>
  );
}

export default App;
