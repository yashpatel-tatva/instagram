import { useSelector } from "react-redux";
import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axiosInstance from "../../helpers/axiousinstance";

const initialState = {
    user: {},
    Notification: {},
    ErrorMessage: '',
    isError: false,
    loading: false,
    success: false
};


const useractionSlice = createSlice({
    name: "useraction",
    initialState,
    reducers: {

    },
    extraReducers: (builder) => {
        builder
            .addCase(getuserdata.fulfilled, (state, action) => {
                console.log("here")
                state.success = true;
                state.user = action;
            })
            .addCase(getuserdata.pending, (state, action) => {
                console.log("pend")
            })
            .addCase(getuserdata.rejected, (state, action) => {
                console.log("rejected")
            })
    }
})

export const getuserdata = createAsyncThunk("user/getuserdata", async (userId, thunkAPI) => {
    try {
        const response = await axiosInstance.get(`/User/GetUserById?userId=${userId}`);
        if (response.status >= 200 && response.status < 300) {
            return response.data;
        } else {
            return thunkAPI.rejectWithValue(await response.data);
        }
    } catch (error) {
        if (error.response) {
            return thunkAPI.rejectWithValue(error.response.data);
        } else {
            return thunkAPI.rejectWithValue({ message: error.message });
        }
    }
});

export const userAction = useractionSlice.actions;

export const useSelectorUserAction = () => {
    const userAction = useSelector((state) => state?.useraction);
    return userAction;
}


export default useractionSlice.reducer;