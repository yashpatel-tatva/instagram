import React from 'react'

const Messages = () => {
    return (
        <div>
            messages
        </div>
    )
}

export default Messages
